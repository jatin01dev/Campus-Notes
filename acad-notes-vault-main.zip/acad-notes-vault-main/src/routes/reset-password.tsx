import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { AuthCard, Field, PasswordInput } from "@/components/auth-card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError } from "@/lib/auth";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a new password — CampusNotes" },
      { name: "description", content: "Choose a new password for your CampusNotes account." },
      { property: "og:title", content: "Set a new password — CampusNotes" },
      { property: "og:description", content: "Finish resetting your CampusNotes password." },
    ],
  }),
  component: Page,
});

function Page() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [pw, setPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const isRecovery = window.location.hash.includes("type=recovery");
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setReady(true);
    });
    supabase.auth.getSession().then(({ data: s }) => {
      if (s.session && isRecovery) setReady(true);
      else if (s.session) setReady(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return setError("Use at least 8 characters with a letter and a number");
    if (pw !== confirm) return setError("Passwords don't match");
    setError("");
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setLoading(false);
    if (error) return setError(friendlyError(error));
    toast.success("Password updated");
    navigate({ to: "/dashboard" });
  }

  return (
    <AuthCard title="Set a new password">
      {!ready ? (
        <p className="text-sm text-muted-foreground">Open this page from the reset link in your email. If the link expired, request a new one.</p>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <Field id="pw" label="New password"><PasswordInput id="pw" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
          <Field id="confirm" label="Confirm new password" error={error}><PasswordInput id="confirm" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} /></Field>
          <Button type="submit" className="w-full" disabled={loading}>{loading && <Loader2 className="animate-spin" />} Update password</Button>
        </form>
      )}
    </AuthCard>
  );
}
