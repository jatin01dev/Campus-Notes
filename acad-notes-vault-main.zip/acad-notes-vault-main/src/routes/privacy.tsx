import { createFileRoute } from "@tanstack/react-router";
import { ContentPage } from "@/components/site-chrome";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — CampusNotes" },
      { name: "description", content: "What data CampusNotes stores and how it is used." },
      { property: "og:title", content: "Privacy Policy — CampusNotes" },
      { property: "og:description", content: "How CampusNotes handles your personal information." },
    ],
  }),
  component: () => (
    <ContentPage title="Privacy Policy">
      <p>We store only what is needed to run the platform: your name, email, branch, semester, role, bookmarks, uploads, and a record of which notes you download.</p>
      <h2>Who can see your information</h2>
      <p>Your email and profile are visible only to you and administrators. If you upload notes, your name is shown as the contributor.</p>
      <h2>Files</h2>
      <p>PDFs are stored privately and can only be opened by signed-in users through short-lived links.</p>
      <h2>Your choices</h2>
      <p>You can edit your profile at any time and ask an administrator to remove your account and uploads.</p>
    </ContentPage>
  ),
});
