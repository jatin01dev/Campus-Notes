import { createFileRoute } from "@tanstack/react-router";
import { ContentPage } from "@/components/site-chrome";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — CampusNotes" },
      { name: "description", content: "Get in touch with the CampusNotes team." },
      { property: "og:title", content: "Contact — CampusNotes" },
      { property: "og:description", content: "Questions, feedback or content concerns? Reach the CampusNotes team." },
    ],
  }),
  component: () => (
    <ContentPage title="Contact">
      <p>For questions about your account or a note, please reach out to your college's CampusNotes administrators.</p>
      <p>To flag a specific note, open it and use the <strong className="text-foreground">Report Note</strong> button — reports go straight to the moderation queue.</p>
    </ContentPage>
  ),
});
