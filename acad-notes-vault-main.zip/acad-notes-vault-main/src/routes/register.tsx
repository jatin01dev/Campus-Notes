import { createFileRoute, Link } from "@tanstack/react-router";
import { Loader2, MailCheck } from "lucide-react";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { AuthCard, Field, PasswordInput } from "@/components/auth-card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError } from "@/lib/auth";
import { useCatalog } from "@/lib/catalog";
import { APP_CONFIG } from "@/lib/config";
import { isAllowedEmail } from "@/lib/validation";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create account — CampusNotes" },
      { name: "description", content: "Join CampusNotes to discover and share college study notes." },
      { property: "og:title", content: "Create account — CampusNotes" },
      { property: "og:description", content: "Sign up free with your college email." },
    ],
  }),
  component: RegisterPage,
});

const schema = z
  .object({
    fullName: z.string().trim().min(2, "Enter your full name").max(120),
    email: z.string().trim().email("Enter a valid email address").refine((e) => isAllowedEmail(e), {
      message: `Use your college email (${APP_CONFIG.allowedEmailDomains.join(", ")})`,
    }),
    password: z.string().min(8, "Use at least 8 characters").regex(/[A-Za-z]/, "Include a letter").regex(/[0-9]/, "Include a number"),
    confirm: z.string(),
    branchId: z.string().min(1, "Select your branch"),
    semesterId: z.string().min(1, "Select your semester"),
    terms: z.literal(true, { errorMap: () => ({ message: "Please accept the terms" }) }),
  })
  .refine((v) => v.password === v.confirm, { path: ["confirm"], message: "Passwords don't match" });

function RegisterPage() {
  const { data: catalog } = useCatalog();
  const [v, setV] = useState({ fullName: "", email: "", password: "", confirm: "", branchId: "", semesterId: "", terms: false });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [loading, setLoading] = useState(false);
  const [sentTo, setSentTo] = useState("");

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError("");
    const parsed = schema.safeParse(v);
    if (!parsed.success) {
      setErrors(Object.fromEntries(parsed.error.issues.map((i) => [i.path[0], i.message])));
      return;
    }
    setErrors({});
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`,
        data: { full_name: parsed.data.fullName, branch_id: parsed.data.branchId, semester_id: parsed.data.semesterId },
      },
    });
    setLoading(false);
    if (error) return setFormError(friendlyError(error));
    if (data.user && data.user.identities?.length === 0) return setFormError("An account with this email already exists.");
    setSentTo(parsed.data.email);
  }

  if (sentTo) {
    return (
      <AuthCard title="Check your email" footer={<Link to="/login" className="font-semibold text-primary hover:underline">Back to login</Link>}>
        <div className="flex flex-col items-center text-center">
          <MailCheck className="h-10 w-10 text-success" />
          <p className="mt-3 text-sm text-muted-foreground">We sent a confirmation link to <strong className="text-foreground">{sentTo}</strong>. Click it to activate your account.</p>
        </div>
      </AuthCard>
    );
  }

  return (
    <AuthCard title="Create your account" subtitle="Join your college's notes community." footer={<>Already have an account? <Link to="/login" className="font-semibold text-primary hover:underline">Log in</Link></>}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        {formError && <div role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-destructive">{formError}</div>}
        <Field id="fullName" label="Full name" error={errors["fullName"]}>
          <Input id="fullName" autoComplete="name" className="h-10" value={v.fullName} onChange={(e) => setV({ ...v, fullName: e.target.value })} />
        </Field>
        <Field id="email" label="College email" error={errors["email"]}>
          <Input id="email" type="email" autoComplete="email" className="h-10" value={v.email} onChange={(e) => setV({ ...v, email: e.target.value })} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="password" label="Password" error={errors["password"]}>
            <PasswordInput id="password" autoComplete="new-password" value={v.password} onChange={(e) => setV({ ...v, password: e.target.value })} />
          </Field>
          <Field id="confirm" label="Confirm password" error={errors["confirm"]}>
            <PasswordInput id="confirm" autoComplete="new-password" value={v.confirm} onChange={(e) => setV({ ...v, confirm: e.target.value })} />
          </Field>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="branch" label="Branch" error={errors["branchId"]}>
            <Select value={v.branchId} onValueChange={(x) => setV({ ...v, branchId: x })}>
              <SelectTrigger id="branch" className="h-10"><SelectValue placeholder="Select branch" /></SelectTrigger>
              <SelectContent>{catalog?.branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field id="semester" label="Current semester" error={errors["semesterId"]}>
            <Select value={v.semesterId} onValueChange={(x) => setV({ ...v, semesterId: x })}>
              <SelectTrigger id="semester" className="h-10"><SelectValue placeholder="Select semester" /></SelectTrigger>
              <SelectContent>{catalog?.semesters.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
        </div>
        <div>
          <label className="flex items-start gap-2 text-sm">
            <Checkbox checked={v.terms} onCheckedChange={(c) => setV({ ...v, terms: c === true })} className="mt-0.5" aria-label="Accept terms" />
            <span>I agree to the <Link to="/terms" className="text-primary hover:underline">Terms</Link> and <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.</span>
          </label>
          {errors["terms"] && <p className="mt-1 text-xs font-medium text-destructive">{errors["terms"]}</p>}
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="animate-spin" />} Create account
        </Button>
      </form>
    </AuthCard>
  );
}
