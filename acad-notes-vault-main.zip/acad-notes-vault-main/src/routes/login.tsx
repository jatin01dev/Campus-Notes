import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { AuthCard, Field, PasswordInput } from "@/components/auth-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError } from "@/lib/auth";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in — CampusNotes" },
      { name: "description", content: "Log in to CampusNotes to explore and download college notes." },
      { property: "og:title", content: "Log in — CampusNotes" },
      { property: "og:description", content: "Access your CampusNotes account." },
    ],
  }),
  component: LoginPage,
});

const schema = z.object({
  email: z.string().trim().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

function LoginPage() {
  const navigate = useNavigate();
  const [values, setValues] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError("");
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      setErrors(Object.fromEntries(parsed.error.issues.map((i) => [i.path[0], i.message])));
      return;
    }
    setErrors({});
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword(parsed.data);
    setLoading(false);
    if (error) return setFormError(friendlyError(error));
    navigate({ to: "/dashboard" });
  }

  return (
    <AuthCard title="Welcome back" subtitle="Log in to continue to CampusNotes." footer={<>New here? <Link to="/register" className="font-semibold text-primary hover:underline">Create an account</Link></>}>
      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        {formError && <div role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-destructive">{formError}</div>}
        <Field id="email" label="Email address" error={errors["email"]}>
          <Input id="email" type="email" autoComplete="email" className="h-10" value={values.email} onChange={(e) => setValues({ ...values, email: e.target.value })} aria-invalid={!!errors["email"]} />
        </Field>
        <Field id="password" label="Password" error={errors["password"]}>
          <PasswordInput id="password" autoComplete="current-password" value={values.password} onChange={(e) => setValues({ ...values, password: e.target.value })} aria-invalid={!!errors["password"]} />
        </Field>
        <div className="flex justify-end">
          <Link to="/forgot-password" className="text-sm font-medium text-primary hover:underline">Forgot password?</Link>
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="animate-spin" />} Log in
        </Button>
      </form>
    </AuthCard>
  );
}
