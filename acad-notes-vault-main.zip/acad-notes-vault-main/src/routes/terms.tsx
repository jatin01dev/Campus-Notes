import { createFileRoute } from "@tanstack/react-router";
import { ContentPage } from "@/components/site-chrome";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Use — CampusNotes" },
      { name: "description", content: "Rules for using and contributing to CampusNotes." },
      { property: "og:title", content: "Terms of Use — CampusNotes" },
      { property: "og:description", content: "The rules every CampusNotes member agrees to." },
    ],
  }),
  component: () => (
    <ContentPage title="Terms of Use">
      <p>By using CampusNotes you agree to share only material you created or have permission to share, and to use downloaded notes for personal study.</p>
      <h2>Content rules</h2>
      <p>No copyrighted textbooks, exam papers you aren't allowed to share, misleading content or anything offensive. Administrators may remove content and suspend accounts that break these rules.</p>
      <h2>Accounts</h2>
      <p>Keep your password private. You are responsible for activity on your account.</p>
    </ContentPage>
  ),
});
