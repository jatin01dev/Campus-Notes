import { createFileRoute, Link } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { AuthCard, Field } from "@/components/auth-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError } from "@/lib/auth";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset password — CampusNotes" },
      { name: "description", content: "Get a link to reset your CampusNotes password." },
      { property: "og:title", content: "Reset password — CampusNotes" },
      { property: "og:description", content: "Forgot your password? Reset it by email." },
    ],
  }),
  component: Page,
});

function Page() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const p = z.string().trim().email().safeParse(email);
    if (!p.success) return setError("Enter a valid email address");
    setError("");
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(p.data, { redirectTo: `${window.location.origin}/reset-password` });
    setLoading(false);
    if (error) return setError(friendlyError(error));
    setSent(true);
  }

  return (
    <AuthCard title="Forgot your password?" subtitle="We'll email you a link to set a new one." footer={<Link to="/login" className="font-semibold text-primary hover:underline">Back to login</Link>}>
      {sent ? (
        <p className="text-sm text-muted-foreground">If an account exists for <strong className="text-foreground">{email}</strong>, a reset link is on its way.</p>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <Field id="email" label="Email address" error={error}>
            <Input id="email" type="email" className="h-10" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Button type="submit" className="w-full" disabled={loading}>{loading && <Loader2 className="animate-spin" />} Send reset link</Button>
        </form>
      )}
    </AuthCard>
  );
}
