import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ContentPage } from "@/components/site-chrome";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How It Works — CampusNotes" },
      { name: "description", content: "How students find, save and share notes on CampusNotes, and how contributors get approved." },
      { property: "og:title", content: "How It Works — CampusNotes" },
      { property: "og:description", content: "Find, save and share college notes in three simple steps." },
    ],
  }),
  component: () => (
    <ContentPage title="How CampusNotes works">
      <h2>1. Sign up as a student</h2>
      <p>Register with your college email, branch and current semester. Every new account starts as a student who can browse, preview, bookmark and download approved notes.</p>
      <h2>2. Explore and save notes</h2>
      <p>Use search and filters for branch, semester and subject. Bookmark anything useful — your bookmarks sync across devices.</p>
      <h2>3. Apply to contribute</h2>
      <p>Want to share? Submit a short contributor application. An administrator reviews it, and once approved you can upload PDF notes.</p>
      <h2>4. Moderation keeps quality high</h2>
      <p>New uploads are reviewed before they appear in the library. Anyone can report a note that is wrong, duplicated or shared without permission.</p>
      <div className="pt-4"><Button asChild><Link to="/register">Create your account</Link></Button></div>
    </ContentPage>
  ),
});
