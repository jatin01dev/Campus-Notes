import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { EmptyState, ErrorState, LoadingState, PageHeader } from "@/components/brand";
import { NoteCard } from "@/components/note-card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { NOTE_SELECT, type NoteWithRefs } from "@/lib/notes";

export const Route = createFileRoute("/_authenticated/bookmarks")({
  head: () => ({ meta: [{ title: "Bookmarks — CampusNotes" }, { name: "description", content: "Notes you've saved." }, { property: "og:title", content: "Bookmarks — CampusNotes" }, { property: "og:description", content: "Your saved notes on CampusNotes." }] }),
  component: Bookmarks,
});

function Bookmarks() {
  const { user } = useAuth();
  const q = useQuery({
    queryKey: ["bookmarks", "all", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("bookmarks").select(`note_id, notes(${NOTE_SELECT})`).eq("user_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return (data as unknown as { notes: NoteWithRefs | null }[]).map((b) => b.notes).filter(Boolean) as NoteWithRefs[];
    },
  });
  return (
    <div>
      <PageHeader title="Bookmarks" description="Your saved notes, synced across devices." />
      {q.isLoading ? <LoadingState /> : q.isError ? <ErrorState onRetry={() => q.refetch()} /> : !q.data?.length ? (
        <EmptyState title="No bookmarks yet" description="Save notes from the library to find them quickly later." action={<Button asChild><Link to="/notes">Explore notes</Link></Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{q.data.map((n) => <NoteCard key={n.id} note={n} />)}</div>
      )}
    </div>
  );
}
