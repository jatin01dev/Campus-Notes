import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Loader2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Field } from "@/components/auth-card";
import { LoadingState, PageHeader, StatusBadge } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/apply")({
  head: () => ({ meta: [{ title: "Become a Contributor — CampusNotes" }, { name: "description", content: "Apply to upload notes on CampusNotes." }, { property: "og:title", content: "Become a Contributor — CampusNotes" }, { property: "og:description", content: "Share your notes with your college." }] }),
  component: Apply,
});

function Apply() {
  const { user, canUpload, roles } = useAuth();
  const qc = useQueryClient();
  const [reason, setReason] = useState("");
  const q = useQuery({
    queryKey: ["my-application", user?.id, "full"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("contributor_applications").select("*").eq("user_id", user!.id).order("created_at", { ascending: false }).limit(1).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const submit = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("contributor_applications").insert({ user_id: user!.id, reason: reason.trim().slice(0, 1000) || null });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Application submitted"); qc.invalidateQueries({ queryKey: ["my-application"] }); },
    onError: (e) => toast.error(friendlyError(e)),
  });

  if (canUpload || roles.includes("contributor")) {
    return (
      <div className="surface mx-auto max-w-lg p-8 text-center">
        <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
        <h1 className="mt-4 text-2xl font-bold">You're a contributor</h1>
        <p className="mt-2 text-muted-foreground">You can upload notes for your classmates.</p>
        <Button className="mt-6" asChild><Link to="/upload">Upload notes</Link></Button>
      </div>
    );
  }
  if (q.isLoading) return <LoadingState />;
  const status = q.data?.status ?? "not applied";

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Become a Contributor" description="Contributors can upload PDF notes for everyone in the community." />
      <div className="surface mb-6 p-6">
        <h2 className="font-semibold">Contributor responsibilities</h2>
        <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
          <li>Upload only notes you wrote or have permission to share.</li>
          <li>Give accurate titles, subjects and descriptions.</li>
          <li>No copyrighted textbooks or restricted exam papers.</li>
          <li>Accept that uploads are reviewed and may be removed.</li>
        </ul>
        <div className="mt-4 flex items-center gap-2 text-sm">Application status: <StatusBadge status={status} /></div>
      </div>
      {status === "pending" ? (
        <div className="surface p-6 text-sm text-muted-foreground">Your application is being reviewed. You'll get upload access as soon as an administrator approves it.</div>
      ) : (
        <form className="surface space-y-4 p-6" onSubmit={(e: FormEvent) => { e.preventDefault(); submit.mutate(); }}>
          {status === "rejected" && <p className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-destructive">Your previous application wasn't approved. You may apply again.</p>}
          <Field id="reason" label="Why do you want to contribute? (optional)">
            <Textarea id="reason" rows={4} maxLength={1000} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. I keep detailed notes for DBMS and OS…" />
          </Field>
          <div className="flex justify-end"><Button type="submit" disabled={submit.isPending}>{submit.isPending && <Loader2 className="animate-spin" />} Submit application</Button></div>
        </form>
      )}
    </div>
  );
}
