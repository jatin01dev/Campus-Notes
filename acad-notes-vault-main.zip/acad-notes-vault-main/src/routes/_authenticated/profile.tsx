import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Field } from "@/components/auth-card";
import { PageHeader, StatusBadge } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, roleLabel, useAuth } from "@/lib/auth";
import { useCatalog } from "@/lib/catalog";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Profile — CampusNotes" }, { name: "description", content: "Your CampusNotes profile." }, { property: "og:title", content: "Profile — CampusNotes" }, { property: "og:description", content: "View and edit your profile." }] }),
  component: Profile,
});

function Profile() {
  const { profile, roles, user, refresh, canUpload } = useAuth();
  const { data: catalog } = useCatalog();
  const [v, setV] = useState({ fullName: "", branchId: "", semesterId: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) setV({ fullName: profile.full_name, branchId: profile.branch_id ?? "", semesterId: profile.semester_id ?? "" });
  }, [profile]);

  const app = useQuery({
    queryKey: ["my-application", user?.id],
    enabled: !!user && !canUpload,
    queryFn: async () => {
      const { data } = await supabase.from("contributor_applications").select("status").eq("user_id", user!.id).order("created_at", { ascending: false }).limit(1).maybeSingle();
      return data?.status ?? "not applied";
    },
  });

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const name = v.fullName.trim();
    if (name.length < 2 || name.length > 120) return setError("Enter your full name");
    setError("");
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ full_name: name, branch_id: v.branchId || null, semester_id: v.semesterId || null }).eq("id", user!.id);
    setSaving(false);
    if (error) return toast.error(friendlyError(error));
    await refresh();
    toast.success("Profile updated");
  }

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Your profile" />
      <div className="surface mb-6 grid gap-4 p-6 sm:grid-cols-3">
        <div><p className="text-xs text-muted-foreground">Email</p><p className="truncate font-medium">{user?.email}</p></div>
        <div><p className="text-xs text-muted-foreground">Role</p><p className="font-medium">{roleLabel(roles)}</p></div>
        {!canUpload && (
          <div><p className="text-xs text-muted-foreground">Contributor application</p>
            <div className="mt-0.5 flex items-center gap-2"><StatusBadge status={app.data ?? "…"} />{app.data !== "pending" && <Link to="/apply" className="text-xs font-medium text-primary hover:underline">Apply</Link>}</div>
          </div>
        )}
      </div>
      <form onSubmit={onSubmit} className="surface space-y-4 p-6" noValidate>
        <Field id="fullName" label="Full name" error={error}><Input id="fullName" className="h-10" maxLength={120} value={v.fullName} onChange={(e) => setV({ ...v, fullName: e.target.value })} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="branch" label="Branch">
            <Select value={v.branchId} onValueChange={(x) => setV({ ...v, branchId: x })}><SelectTrigger id="branch" className="h-10"><SelectValue placeholder="Select branch" /></SelectTrigger><SelectContent>{catalog?.branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent></Select>
          </Field>
          <Field id="semester" label="Semester">
            <Select value={v.semesterId} onValueChange={(x) => setV({ ...v, semesterId: x })}><SelectTrigger id="semester" className="h-10"><SelectValue placeholder="Select semester" /></SelectTrigger><SelectContent>{catalog?.semesters.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select>
          </Field>
        </div>
        <div className="flex justify-end"><Button type="submit" disabled={saving}>{saving && <Loader2 className="animate-spin" />} Save changes</Button></div>
      </form>
    </div>
  );
}
