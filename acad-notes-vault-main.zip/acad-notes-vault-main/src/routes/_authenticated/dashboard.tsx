import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Search } from "lucide-react";
import { useState, type FormEvent } from "react";
import { EmptyState, ErrorState, LoadingState } from "@/components/brand";
import { NoteCard } from "@/components/note-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useCatalog } from "@/lib/catalog";
import { NOTE_SELECT, type NoteWithRefs } from "@/lib/notes";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — CampusNotes" }, { name: "description", content: "Your CampusNotes dashboard." }, { property: "og:title", content: "Dashboard — CampusNotes" }, { property: "og:description", content: "Recent and popular college notes." }] }),
  component: Dashboard,
});

function useNoteList(key: string, order: "created_at" | "download_count") {
  return useQuery({
    queryKey: ["notes", key],
    queryFn: async () => {
      const { data, error } = await supabase.from("notes").select(NOTE_SELECT).eq("moderation_status", "approved").order(order, { ascending: false }).limit(6);
      if (error) throw error;
      return data as unknown as NoteWithRefs[];
    },
  });
}

function NoteGrid({ q }: { q: ReturnType<typeof useNoteList> }) {
  if (q.isLoading) return <LoadingState />;
  if (q.isError) return <ErrorState onRetry={() => q.refetch()} />;
  if (!q.data?.length) return <EmptyState title="No notes yet" description="Approved notes will appear here once contributors start sharing." />;
  return <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{q.data.map((n) => <NoteCard key={n.id} note={n} />)}</div>;
}

function Dashboard() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const { data: catalog } = useCatalog();
  const [q, setQ] = useState("");
  const recent = useNoteList("recent", "created_at");
  const popular = useNoteList("popular", "download_count");
  const bookmarks = useQuery({
    queryKey: ["bookmarks", "preview"],
    queryFn: async () => {
      const { data, error } = await supabase.from("bookmarks").select(`note_id, notes(${NOTE_SELECT})`).order("created_at", { ascending: false }).limit(3);
      if (error) throw error;
      return (data as unknown as { notes: NoteWithRefs | null }[]).map((b) => b.notes).filter(Boolean) as NoteWithRefs[];
    },
  });
  const mySubjects = catalog?.subjects.filter((s) => s.branch_id === profile?.branch_id) ?? [];

  function onSearch(e: FormEvent) {
    e.preventDefault();
    navigate({ to: "/notes", search: { q: q.trim() || undefined } });
  }

  return (
    <div className="space-y-10">
      <section className="rounded-2xl bg-ink p-6 text-ink-foreground sm:p-8">
        <h1 className="text-2xl font-bold sm:text-3xl">Welcome back, {profile?.full_name?.split(" ")[0] ?? "there"} 👋</h1>
        <p className="mt-1 opacity-80">What are you studying today?</p>
        <form onSubmit={onSearch} className="mt-5 flex max-w-xl gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search notes, subjects…" aria-label="Search notes" className="h-11 bg-card pl-9 text-foreground" />
          </div>
          <Button type="submit" size="lg" className="h-11">Search</Button>
        </form>
      </section>

      <section>
        <h2 className="mb-3 text-lg font-semibold">Browse by branch & semester</h2>
        <div className="flex flex-wrap gap-2">
          {catalog?.branches.map((b) => (
            <Button key={b.id} variant="outline" size="sm" asChild><Link to="/notes" search={{ branch: b.id }}>{b.code}</Link></Button>
          ))}
          {catalog?.semesters.map((s) => (
            <Button key={s.id} variant="secondary" size="sm" asChild><Link to="/notes" search={{ semester: s.id }}>Sem {s.number}</Link></Button>
          ))}
        </div>
        {mySubjects.length > 0 && (
          <>
            <h3 className="mb-2 mt-5 text-sm font-semibold text-muted-foreground">Subjects in your branch</h3>
            <div className="flex flex-wrap gap-2">
              {mySubjects.map((s) => <Button key={s.id} variant="soft" size="sm" asChild><Link to="/notes" search={{ subject: s.id, branch: s.branch_id, semester: s.semester_id }}>{s.name}</Link></Button>)}
            </div>
          </>
        )}
      </section>

      <section>
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-semibold">Recently uploaded</h2><Button variant="link" asChild><Link to="/notes">Browse all notes <ArrowRight /></Link></Button></div>
        <NoteGrid q={recent} />
      </section>
      <section>
        <h2 className="mb-4 text-lg font-semibold">Popular notes</h2>
        <NoteGrid q={popular} />
      </section>
      <section>
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-semibold">Your bookmarks</h2><Button variant="link" asChild><Link to="/bookmarks">See all</Link></Button></div>
        {bookmarks.isLoading ? <LoadingState /> : bookmarks.isError ? <ErrorState onRetry={() => bookmarks.refetch()} /> : bookmarks.data?.length ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{bookmarks.data.map((n) => <NoteCard key={n.id} note={n} />)}</div>
        ) : <EmptyState title="No bookmarks yet" description="Tap the bookmark icon on any note to save it here." />}
      </section>
    </div>
  );
}
