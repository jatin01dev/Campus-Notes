import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, FileText, Loader2, UploadCloud, X } from "lucide-react";
import { useRef, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { AccessDenied } from "@/components/access-denied";
import { PageHeader } from "@/components/brand";
import { emptyMeta, metaSchema, NoteMetaFields, type NoteMeta } from "@/components/note-meta-fields";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, useAuth } from "@/lib/auth";
import { APP_CONFIG } from "@/lib/config";
import { buildStoragePath, formatBytes, validatePdfFile } from "@/lib/validation";

export const Route = createFileRoute("/_authenticated/upload")({
  head: () => ({ meta: [{ title: "Upload Notes — CampusNotes" }, { name: "description", content: "Share PDF notes with your college." }, { property: "og:title", content: "Upload Notes — CampusNotes" }, { property: "og:description", content: "Contributors can upload PDF notes." }] }),
  component: UploadPage,
});

type Stage = "idle" | "uploading" | "saving" | "done";

function UploadPage() {
  const { canUpload, user, isAdmin } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [meta, setMeta] = useState<NoteMeta>(emptyMeta);
  const [file, setFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [stage, setStage] = useState<Stage>("idle");

  if (!canUpload) return <AccessDenied showApply message="Only approved contributors can upload notes. Apply to become a contributor first." />;

  async function pickFile(f: File | undefined) {
    if (!f) return;
    const check = await validatePdfFile(f);
    if (!check.ok) { setFile(null); setErrors((e) => ({ ...e, file: check.error })); if (inputRef.current) inputRef.current.value = ""; return; }
    setErrors((e) => ({ ...e, file: "" }));
    setFile(f);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (stage !== "idle") return;
    const parsed = metaSchema.safeParse(meta);
    const errs: Record<string, string> = parsed.success ? {} : Object.fromEntries(parsed.error.issues.map((i) => [i.path[0], i.message]));
    if (!file) errs["file"] = "Choose a PDF file";
    setErrors(errs);
    if (!parsed.success || !file || !user) return;
    const check = await validatePdfFile(file);
    if (!check.ok) return setErrors({ file: check.error });

    const path = buildStoragePath(user.id, crypto.randomUUID());
    setStage("uploading");
    const up = await supabase.storage.from("college-notes").upload(path, file, { contentType: "application/pdf", upsert: false });
    if (up.error) { setStage("idle"); return toast.error(friendlyError(up.error, "Upload failed. Please try again.")); }

    setStage("saving");
    const { error } = await supabase.from("notes").insert({
      title: parsed.data.title, description: parsed.data.description || null,
      branch_id: parsed.data.branchId, semester_id: parsed.data.semesterId, subject_id: parsed.data.subjectId,
      storage_path: path, file_size: file.size, uploaded_by: user.id,
    });
    if (error) {
      await supabase.storage.from("college-notes").remove([path]); // clean up orphaned file
      setStage("idle");
      return toast.error(friendlyError(error, "Couldn't save your note. Please try again."));
    }
    setStage("done");
    qc.invalidateQueries({ queryKey: ["my-uploads"] });
    toast.success(isAdmin ? "Note uploaded." : "Note uploaded! It will appear in the library after review.");
  }

  if (stage === "done") {
    return (
      <div className="surface mx-auto max-w-lg p-8 text-center">
        <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
        <h1 className="mt-4 text-2xl font-bold">Upload complete</h1>
        <p className="mt-2 text-muted-foreground">{isAdmin ? "Approve it from the admin dashboard to publish it." : "An administrator will review your note before it's published."}</p>
        <div className="mt-6 flex justify-center gap-2">
          <Button variant="outline" onClick={() => { setMeta(emptyMeta); setFile(null); setStage("idle"); }}>Upload another</Button>
          <Button onClick={() => navigate({ to: "/my-uploads" })}>View my uploads</Button>
        </div>
      </div>
    );
  }

  const busy = stage !== "idle";
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Upload Notes" description={`PDF only, up to ${APP_CONFIG.maxUploadMb} MB. Uploads are reviewed before publishing.`} />
      <form onSubmit={onSubmit} className="surface space-y-6 p-6 sm:p-8" noValidate>
        <NoteMetaFields value={meta} onChange={setMeta} errors={errors} />
        <div>
          <p className="mb-1.5 text-sm font-medium">PDF file</p>
          {file ? (
            <div className="flex items-center gap-3 rounded-lg border bg-secondary/50 p-3">
              <FileText className="h-8 w-8 shrink-0 text-destructive" />
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{file.name}</p><p className="text-xs text-muted-foreground">{formatBytes(file.size)}</p></div>
              <Button type="button" variant="ghost" size="icon" aria-label="Remove file" disabled={busy} onClick={() => { setFile(null); if (inputRef.current) inputRef.current.value = ""; }}><X /></Button>
            </div>
          ) : (
            <label
              className="flex cursor-pointer flex-col items-center gap-2 rounded-lg border-2 border-dashed p-8 text-center transition-colors hover:border-primary hover:bg-primary-soft/40"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); void pickFile(e.dataTransfer.files[0]); }}
            >
              <UploadCloud className="h-8 w-8 text-primary" />
              <span className="text-sm font-medium">Click to choose or drag a PDF here</span>
              <span className="text-xs text-muted-foreground">Max {APP_CONFIG.maxUploadMb} MB</span>
              <input ref={inputRef} type="file" accept="application/pdf,.pdf" className="sr-only" onChange={(e) => void pickFile(e.target.files?.[0])} />
            </label>
          )}
          {errors["file"] && <p className="mt-1 text-xs font-medium text-destructive">{errors["file"]}</p>}
        </div>
        {busy && (
          <div className="space-y-1.5" role="status">
            <Progress value={stage === "uploading" ? 45 : 90} />
            <p className="text-xs text-muted-foreground">{stage === "uploading" ? "Uploading file…" : "Saving details…"}</p>
          </div>
        )}
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" asChild><Link to="/my-uploads">Cancel</Link></Button>
          <Button type="submit" disabled={busy}>{busy && <Loader2 className="animate-spin" />} Upload</Button>
        </div>
      </form>
    </div>
  );
}
