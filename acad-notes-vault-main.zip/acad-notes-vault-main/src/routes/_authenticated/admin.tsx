import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Download, Trash2, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AccessDenied } from "@/components/access-denied";
import { EmptyState, ErrorState, LoadingState, PageHeader, StatusBadge } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, useAuth } from "@/lib/auth";
import { useCatalog } from "@/lib/catalog";
import { downloadNote, formatDate, NOTE_SELECT, type NoteWithRefs } from "@/lib/notes";
import { deleteNoteAndFile } from "./my-uploads";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — CampusNotes" }, { name: "description", content: "CampusNotes administration." }, { property: "og:title", content: "Admin — CampusNotes" }, { property: "og:description", content: "Moderate notes, users and applications." }] }),
  component: Admin,
});

function useAct() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (fn: () => PromiseLike<unknown>) => {
      const r = (await fn()) as { error?: unknown } | undefined;
      if (r && r.error) throw r.error;
    },
    onSuccess: () => { toast.success("Done"); qc.invalidateQueries({ queryKey: ["admin"] }); qc.invalidateQueries({ queryKey: ["catalog"] }); qc.invalidateQueries({ queryKey: ["notes"] }); },
    onError: (e) => toast.error(friendlyError(e)),
  });
}

function Admin() {
  const { isAdmin } = useAuth();
  if (!isAdmin) return <AccessDenied message="This area is for administrators only." />;
  return (
    <div>
      <PageHeader title="Admin dashboard" description="Moderate content and manage the community." />
      <Stats />
      <Tabs defaultValue="applications" className="mt-8">
        <TabsList className="flex h-auto flex-wrap justify-start">
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="notes">Notes moderation</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="catalog">Branches & subjects</TabsTrigger>
        </TabsList>
        <TabsContent value="applications"><Applications /></TabsContent>
        <TabsContent value="notes"><NotesModeration /></TabsContent>
        <TabsContent value="reports"><Reports /></TabsContent>
        <TabsContent value="users"><Users /></TabsContent>
        <TabsContent value="catalog"><Catalog /></TabsContent>
      </Tabs>
    </div>
  );
}

function Stats() {
  const q = useQuery({
    queryKey: ["admin", "stats"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_admin_stats");
      if (error) throw error;
      return data as Record<string, number>;
    },
  });
  if (q.isError) return <ErrorState onRetry={() => q.refetch()} />;
  const items = [["Registered users", "users"], ["Contributors", "contributors"], ["Total notes", "notes"], ["Pending notes", "pending_notes"], ["Pending applications", "pending_applications"], ["Open reports", "open_reports"]];
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
      {items.map(([label, key]) => (
        <div key={key} className="surface p-4"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 font-display text-2xl font-bold">{q.data?.[key as string] ?? "–"}</p></div>
      ))}
    </div>
  );
}

function useProfilesMap(ids: string[]) {
  return useQuery({
    queryKey: ["admin", "profiles", ids.sort().join(",")],
    enabled: ids.length > 0,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
      return new Map((data ?? []).map((p) => [p.id, p]));
    },
  });
}

function Applications() {
  const act = useAct();
  const q = useQuery({
    queryKey: ["admin", "applications"],
    queryFn: async () => {
      const { data, error } = await supabase.from("contributor_applications").select("*").order("created_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data;
    },
  });
  const people = useProfilesMap([...new Set((q.data ?? []).map((a) => a.user_id))]);
  if (q.isLoading) return <LoadingState />;
  if (q.isError || !q.data) return <ErrorState onRetry={() => q.refetch()} />;
  if (!q.data.length) return <EmptyState title="No applications yet" />;
  return (
    <div className="space-y-3">
      {q.data.map((a) => {
        const p = people.data?.get(a.user_id);
        return (
          <div key={a.id} className="surface flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2"><span className="font-semibold">{p?.full_name ?? "User"}</span><StatusBadge status={a.status} /></div>
              <p className="text-xs text-muted-foreground">{p?.email} · {formatDate(a.created_at)}</p>
              {a.reason && <p className="mt-1 text-sm">{a.reason}</p>}
            </div>
            {a.status === "pending" && (
              <div className="flex gap-2">
                <Button size="sm" disabled={act.isPending} onClick={() => act.mutate(() => supabase.rpc("review_application", { _application_id: a.id, _approve: true }))}><Check /> Approve</Button>
                <Button size="sm" variant="outline" disabled={act.isPending} onClick={() => act.mutate(() => supabase.rpc("review_application", { _application_id: a.id, _approve: false }))}><X /> Reject</Button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function NotesModeration() {
  const act = useAct();
  const [filter, setFilter] = useState<"pending" | "approved" | "rejected">("pending");
  const q = useQuery({
    queryKey: ["admin", "notes", filter],
    queryFn: async () => {
      const { data, error } = await supabase.from("notes").select(NOTE_SELECT).eq("moderation_status", filter).order("created_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data as unknown as NoteWithRefs[];
    },
  });
  const setStatus = (id: string, s: "approved" | "rejected") => act.mutate(() => supabase.from("notes").update({ moderation_status: s }).eq("id", id));
  return (
    <div>
      <div className="mb-4 flex gap-2">
        {(["pending", "approved", "rejected"] as const).map((s) => <Button key={s} size="sm" variant={filter === s ? "default" : "outline"} onClick={() => setFilter(s)} className="capitalize">{s}</Button>)}
      </div>
      {q.isLoading ? <LoadingState /> : q.isError ? <ErrorState onRetry={() => q.refetch()} /> : !q.data?.length ? <EmptyState title={`No ${filter} notes`} /> : (
        <div className="space-y-3">
          {q.data.map((n) => (
            <div key={n.id} className="surface flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
              <div className="min-w-0 flex-1">
                <Link to="/notes/$noteId" params={{ noteId: n.id }} className="font-semibold hover:text-primary">{n.title}</Link>
                <p className="text-xs text-muted-foreground">{n.subjects?.name} · {n.branches?.code} · Sem {n.semesters?.number} · by {n.uploader_name} · {formatDate(n.created_at)}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => downloadNote(n).catch((e) => toast.error(friendlyError(e)))}><Download /> Open</Button>
                {filter !== "approved" && <Button size="sm" disabled={act.isPending} onClick={() => setStatus(n.id, "approved")}><Check /> Approve</Button>}
                {filter !== "rejected" && <Button size="sm" variant="outline" disabled={act.isPending} onClick={() => setStatus(n.id, "rejected")}><X /> Reject</Button>}
                <Button size="sm" variant="outline" className="text-destructive" disabled={act.isPending} onClick={() => { if (confirm(`Permanently delete "${n.title}"?`)) act.mutate(() => deleteNoteAndFile(n)); }}><Trash2 /> Remove</Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Reports() {
  const act = useAct();
  const { user } = useAuth();
  const q = useQuery({
    queryKey: ["admin", "reports"],
    queryFn: async () => {
      const { data, error } = await supabase.from("note_reports").select("*, notes(id, title, storage_path)").order("created_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data;
    },
  });
  if (q.isLoading) return <LoadingState />;
  if (q.isError || !q.data) return <ErrorState onRetry={() => q.refetch()} />;
  if (!q.data.length) return <EmptyState title="No reports" description="Nothing has been reported." />;
  return (
    <div className="space-y-3">
      {q.data.map((r) => (
        <div key={r.id} className="surface flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2"><span className="font-semibold">{r.reason}</span><StatusBadge status={r.status} /></div>
            {r.notes && <Link to="/notes/$noteId" params={{ noteId: r.notes.id }} className="text-sm text-primary hover:underline">{r.notes.title}</Link>}
            {r.description && <p className="mt-1 text-sm text-muted-foreground">{r.description}</p>}
            <p className="text-xs text-muted-foreground">{formatDate(r.created_at)}</p>
          </div>
          {r.status !== "resolved" && (
            <div className="flex flex-wrap gap-2">
              {r.status === "open" && <Button size="sm" variant="outline" onClick={() => act.mutate(() => supabase.from("note_reports").update({ status: "reviewing", reviewed_by: user!.id }).eq("id", r.id))}>Mark reviewing</Button>}
              <Button size="sm" onClick={() => act.mutate(() => supabase.from("note_reports").update({ status: "resolved", reviewed_by: user!.id, resolved_at: new Date().toISOString() }).eq("id", r.id))}><Check /> Resolve</Button>
              {r.notes && <Button size="sm" variant="outline" className="text-destructive" onClick={() => { if (confirm("Remove the reported note?")) act.mutate(async () => { await supabase.from("note_reports").update({ status: "resolved", reviewed_by: user!.id, resolved_at: new Date().toISOString() }).eq("id", r.id); await deleteNoteAndFile(r.notes!); }); }}><Trash2 /> Remove note</Button>}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function Users() {
  const act = useAct();
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const q = useQuery({
    queryKey: ["admin", "users"],
    queryFn: async () => {
      const [p, r] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(500),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      if (p.error) throw p.error;
      const roles = new Map<string, string[]>();
      (r.data ?? []).forEach((x) => roles.set(x.user_id, [...(roles.get(x.user_id) ?? []), x.role]));
      return p.data.map((u) => ({ ...u, roles: roles.get(u.id) ?? [] }));
    },
  });
  if (q.isLoading) return <LoadingState />;
  if (q.isError || !q.data) return <ErrorState onRetry={() => q.refetch()} />;
  const list = q.data.filter((u) => !search || `${u.full_name} ${u.email}`.toLowerCase().includes(search.toLowerCase()));
  return (
    <div>
      <Input placeholder="Search users" aria-label="Search users" value={search} onChange={(e) => setSearch(e.target.value)} className="mb-4 h-10 max-w-sm" />
      <div className="surface divide-y">
        {list.map((u) => (
          <div key={u.id} className="flex flex-col gap-2 p-4 sm:flex-row sm:items-center">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{u.full_name}</span><StatusBadge status={u.is_suspended ? "suspended" : "active"} />{u.roles.filter((r) => r !== "student").map((r) => <span key={r} className="rounded-md bg-primary-soft px-2 py-0.5 text-xs font-medium capitalize text-primary">{r}</span>)}</div>
              <p className="truncate text-xs text-muted-foreground">{u.email} · joined {formatDate(u.created_at)}</p>
            </div>
            {u.id !== user?.id && (
              <div className="flex gap-2">
                {u.roles.includes("contributor") && <Button size="sm" variant="outline" onClick={() => act.mutate(() => supabase.rpc("revoke_contributor", { _user_id: u.id }))}>Revoke contributor</Button>}
                <Button size="sm" variant={u.is_suspended ? "default" : "outline"} className={u.is_suspended ? "" : "text-destructive"} onClick={() => act.mutate(() => supabase.from("profiles").update({ is_suspended: !u.is_suspended }).eq("id", u.id))}>{u.is_suspended ? "Reactivate" : "Suspend"}</Button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function Catalog() {
  const act = useAct();
  const { data: c } = useCatalog();
  const [branch, setBranch] = useState({ name: "", code: "" });
  const [sub, setSub] = useState({ name: "", branchId: "", semesterId: "" });
  const [semNum, setSemNum] = useState("");
  if (!c) return <LoadingState />;
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="surface p-5">
        <h3 className="font-semibold">Branches</h3>
        <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (branch.name.trim().length < 2 || !branch.code.trim()) { toast.error("Enter name and code"); return; } act.mutate(() => supabase.from("branches").insert({ name: branch.name.trim(), code: branch.code.trim().toUpperCase().slice(0, 10) })); setBranch({ name: "", code: "" }); }}>
          <Input placeholder="Name" aria-label="Branch name" value={branch.name} onChange={(e) => setBranch({ ...branch, name: e.target.value })} />
          <Input placeholder="Code" aria-label="Branch code" className="w-24" value={branch.code} onChange={(e) => setBranch({ ...branch, code: e.target.value })} />
          <Button type="submit">Add</Button>
        </form>
        <ul className="mt-4 divide-y text-sm">{c.branches.map((b) => <li key={b.id} className="flex items-center justify-between py-2"><span><b>{b.code}</b> — {b.name}</span><Button size="icon" variant="ghost" aria-label={`Delete ${b.name}`} onClick={() => { if (confirm(`Delete ${b.name} and all its subjects?`)) act.mutate(() => supabase.from("branches").delete().eq("id", b.id)); }}><Trash2 /></Button></li>)}</ul>
        <h3 className="mt-6 font-semibold">Semesters</h3>
        <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); const n = Number(semNum); if (!Number.isInteger(n) || n < 1 || n > 12) { toast.error("Enter 1–12"); return; } act.mutate(() => supabase.from("semesters").insert({ number: n, name: `Semester ${n}` })); setSemNum(""); }}>
          <Input type="number" min={1} max={12} placeholder="Number" aria-label="Semester number" value={semNum} onChange={(e) => setSemNum(e.target.value)} />
          <Button type="submit">Add</Button>
        </form>
        <p className="mt-2 text-sm text-muted-foreground">{c.semesters.map((s) => s.number).join(", ")}</p>
      </div>
      <div className="surface p-5">
        <h3 className="font-semibold">Subjects</h3>
        <form className="mt-3 grid gap-2 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); if (sub.name.trim().length < 2 || !sub.branchId || !sub.semesterId) { toast.error("Fill in all subject fields"); return; } act.mutate(() => supabase.from("subjects").insert({ name: sub.name.trim(), branch_id: sub.branchId, semester_id: sub.semesterId })); setSub({ ...sub, name: "" }); }}>
          <Input className="sm:col-span-2" placeholder="Subject name" aria-label="Subject name" value={sub.name} onChange={(e) => setSub({ ...sub, name: e.target.value })} />
          <Select value={sub.branchId} onValueChange={(v) => setSub({ ...sub, branchId: v })}><SelectTrigger aria-label="Branch"><SelectValue placeholder="Branch" /></SelectTrigger><SelectContent>{c.branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.code}</SelectItem>)}</SelectContent></Select>
          <Select value={sub.semesterId} onValueChange={(v) => setSub({ ...sub, semesterId: v })}><SelectTrigger aria-label="Semester"><SelectValue placeholder="Semester" /></SelectTrigger><SelectContent>{c.semesters.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select>
          <Button type="submit" className="sm:col-span-2">Add subject</Button>
        </form>
        <ul className="mt-4 max-h-96 divide-y overflow-auto text-sm">
          {c.subjects.map((s) => (
            <li key={s.id} className="flex items-center justify-between py-2">
              <span>{s.name} <span className="text-muted-foreground">· {c.branches.find((b) => b.id === s.branch_id)?.code} · Sem {c.semesters.find((x) => x.id === s.semester_id)?.number}</span></span>
              <Button size="icon" variant="ghost" aria-label={`Delete ${s.name}`} onClick={() => { if (confirm(`Delete ${s.name}?`)) act.mutate(() => supabase.from("subjects").delete().eq("id", s.id)); }}><Trash2 /></Button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
