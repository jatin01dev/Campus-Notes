import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Bookmark, BookmarkCheck, Download, Eye, Flag, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { EmptyState, ErrorState, LoadingState, StatusBadge } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, useAuth } from "@/lib/auth";
import { useBookmarkIds, useToggleBookmark } from "@/lib/bookmarks";
import { downloadNote, formatDate, getPreviewUrl, NOTE_SELECT, type NoteWithRefs } from "@/lib/notes";
import { formatBytes } from "@/lib/validation";

export const Route = createFileRoute("/_authenticated/notes/$noteId")({
  head: () => ({ meta: [{ title: "Note details — CampusNotes" }, { name: "description", content: "View, preview and download this note." }, { property: "og:title", content: "Note details — CampusNotes" }, { property: "og:description", content: "A shared college note on CampusNotes." }] }),
  component: NoteDetails,
});

const REASONS = ["Inappropriate content", "Misleading or incorrect", "Duplicate", "Copyright / unauthorized", "Other"];

function NoteDetails() {
  const { noteId } = Route.useParams();
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data: ids } = useBookmarkIds();
  const toggle = useToggleBookmark();
  const [preview, setPreview] = useState<string | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");

  const q = useQuery({
    queryKey: ["note", noteId],
    queryFn: async () => {
      const { data, error } = await supabase.from("notes").select(NOTE_SELECT).eq("id", noteId).maybeSingle();
      if (error) throw error;
      return data as unknown as NoteWithRefs | null;
    },
  });

  const report = useMutation({
    mutationFn: async () => {
      if (!reason) throw new Error("Choose a reason");
      const { error } = await supabase.from("note_reports").insert({ note_id: noteId, reported_by: user!.id, reason, description: details.trim().slice(0, 1000) || null });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Thanks — an administrator will review this note."); setReportOpen(false); setReason(""); setDetails(""); },
    onError: (e) => toast.error(e instanceof Error && e.message === "Choose a reason" ? e.message : friendlyError(e)),
  });

  if (q.isLoading) return <LoadingState />;
  if (q.isError) return <ErrorState onRetry={() => q.refetch()} />;
  const note = q.data;
  if (!note) return <EmptyState title="Note not found" description="It may have been removed or isn't published yet." action={<Button asChild><Link to="/notes">Back to library</Link></Button>} />;
  const bookmarked = ids?.has(note.id) ?? false;

  async function onDownload() {
    setDownloading(true);
    try { await downloadNote(note!); qc.invalidateQueries({ queryKey: ["note", noteId] }); }
    catch (e) { toast.error(friendlyError(e, "Download failed. Please try again.")); }
    finally { setDownloading(false); }
  }
  async function onPreview() {
    setPreviewLoading(true);
    try { setPreview(await getPreviewUrl(note!.storage_path)); }
    catch (e) { toast.error(friendlyError(e, "Preview unavailable.")); }
    finally { setPreviewLoading(false); }
  }

  return (
    <div>
      <Button variant="ghost" size="sm" className="mb-4" asChild><Link to="/notes"><ArrowLeft /> Back to library</Link></Button>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="surface p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wide text-primary">{note.subjects?.name}</span>
            {note.moderation_status !== "approved" && <StatusBadge status={note.moderation_status} />}
            {note.is_demo && <span className="rounded-md bg-warning-soft px-2 py-0.5 text-xs font-medium text-warning">Demo content</span>}
          </div>
          <h1 className="mt-2 text-2xl font-bold sm:text-3xl">{note.title}</h1>
          <p className="mt-4 whitespace-pre-line text-muted-foreground">{note.description || "No description provided."}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            <Button onClick={onDownload} disabled={downloading}>{downloading ? <Loader2 className="animate-spin" /> : <Download />} Download PDF</Button>
            <Button variant="outline" onClick={onPreview} disabled={previewLoading}>{previewLoading ? <Loader2 className="animate-spin" /> : <Eye />} Preview</Button>
            <Button variant="outline" onClick={() => toggle.mutate({ noteId: note.id, bookmarked })} disabled={toggle.isPending} aria-pressed={bookmarked}>
              {bookmarked ? <BookmarkCheck /> : <Bookmark />} {bookmarked ? "Bookmarked" : "Bookmark"}
            </Button>
            <Button variant="ghost" onClick={() => setReportOpen(true)}><Flag /> Report Note</Button>
          </div>
          {preview && (
            <div className="mt-6 overflow-hidden rounded-lg border">
              <iframe src={preview} title={`Preview of ${note.title}`} className="h-[70vh] w-full" />
            </div>
          )}
        </div>
        <aside className="surface h-fit p-6">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Details</h2>
          <dl className="mt-4 space-y-3 text-sm">
            {[
              ["Branch", note.branches?.name],
              ["Semester", note.semesters?.name],
              ["Subject", note.subjects?.name],
              ["Contributor", note.uploader_name ?? "Contributor"],
              ["Uploaded", formatDate(note.created_at)],
              ["File", `PDF · ${formatBytes(note.file_size)}`],
              ["Downloads", String(note.download_count)],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4"><dt className="text-muted-foreground">{k}</dt><dd className="text-right font-medium">{v}</dd></div>
            ))}
          </dl>
        </aside>
      </div>

      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Report this note</DialogTitle><DialogDescription>Reports are private and reviewed by administrators.</DialogDescription></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="reason">Reason</Label>
              <Select value={reason} onValueChange={setReason}><SelectTrigger id="reason"><SelectValue placeholder="Choose a reason" /></SelectTrigger><SelectContent>{REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent></Select>
            </div>
            <div className="space-y-1.5"><Label htmlFor="details">Details (optional)</Label><Textarea id="details" maxLength={1000} value={details} onChange={(e) => setDetails(e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReportOpen(false)}>Cancel</Button>
            <Button onClick={() => report.mutate()} disabled={report.isPending}>{report.isPending && <Loader2 className="animate-spin" />} Submit report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
