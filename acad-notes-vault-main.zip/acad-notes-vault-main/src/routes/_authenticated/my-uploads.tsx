import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AccessDenied } from "@/components/access-denied";
import { EmptyState, ErrorState, LoadingState, PageHeader, StatusBadge } from "@/components/brand";
import { metaSchema, NoteMetaFields, type NoteMeta } from "@/components/note-meta-fields";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, useAuth } from "@/lib/auth";
import { formatDate, NOTE_SELECT, type NoteWithRefs } from "@/lib/notes";

export const Route = createFileRoute("/_authenticated/my-uploads")({
  head: () => ({ meta: [{ title: "My Uploads — CampusNotes" }, { name: "description", content: "Manage the notes you've shared." }, { property: "og:title", content: "My Uploads — CampusNotes" }, { property: "og:description", content: "Your uploaded notes and their status." }] }),
  component: MyUploads,
});

export async function deleteNoteAndFile(note: Pick<NoteWithRefs, "id" | "storage_path">) {
  const { error } = await supabase.from("notes").delete().eq("id", note.id);
  if (error) throw error;
  // Record is gone first, so the file is no longer reachable even if removal fails.
  await supabase.storage.from("college-notes").remove([note.storage_path]);
}

function MyUploads() {
  const { user, canUpload } = useAuth();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<NoteWithRefs | null>(null);
  const [meta, setMeta] = useState<NoteMeta | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [deleting, setDeleting] = useState<NoteWithRefs | null>(null);

  const q = useQuery({
    queryKey: ["my-uploads", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("notes").select(NOTE_SELECT).eq("uploaded_by", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data as unknown as NoteWithRefs[];
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      const p = metaSchema.safeParse(meta);
      if (!p.success) { setErrors(Object.fromEntries(p.error.issues.map((i) => [i.path[0], i.message]))); throw new Error("invalid"); }
      const { error } = await supabase.from("notes").update({ title: p.data.title, description: p.data.description || null, subject_id: p.data.subjectId }).eq("id", editing!.id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Changes saved. Edited notes are re-reviewed before publishing."); setEditing(null); qc.invalidateQueries({ queryKey: ["my-uploads"] }); qc.invalidateQueries({ queryKey: ["notes"] }); },
    onError: (e) => { if (e instanceof Error && e.message === "invalid") return; toast.error(friendlyError(e)); },
  });

  const del = useMutation({
    mutationFn: (n: NoteWithRefs) => deleteNoteAndFile(n),
    onSuccess: () => { toast.success("Note deleted"); setDeleting(null); qc.invalidateQueries({ queryKey: ["my-uploads"] }); qc.invalidateQueries({ queryKey: ["notes"] }); },
    onError: (e) => toast.error(friendlyError(e)),
  });

  if (!canUpload) return <AccessDenied showApply message="My Uploads is available to approved contributors." />;

  return (
    <div>
      <PageHeader title="My Uploads" description="Notes you've shared and their review status." action={<Button asChild><Link to="/upload"><Plus /> Upload notes</Link></Button>} />
      {q.isLoading ? <LoadingState /> : q.isError ? <ErrorState onRetry={() => q.refetch()} /> : !q.data?.length ? (
        <EmptyState title="No uploads yet" description="Share your first set of notes with your classmates." action={<Button asChild><Link to="/upload">Upload notes</Link></Button>} />
      ) : (
        <div className="space-y-3">
          {q.data.map((n) => (
            <div key={n.id} className="surface flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2"><Link to="/notes/$noteId" params={{ noteId: n.id }} className="truncate font-semibold hover:text-primary">{n.title}</Link><StatusBadge status={n.moderation_status} /></div>
                <p className="mt-1 text-sm text-muted-foreground">{n.subjects?.name} · {n.branches?.code} · Sem {n.semesters?.number} · {formatDate(n.created_at)}</p>
              </div>
              <span className="flex items-center gap-1 text-sm text-muted-foreground"><Download className="h-4 w-4" /> {n.download_count}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => { setEditing(n); setErrors({}); setMeta({ title: n.title, description: n.description ?? "", branchId: n.branch_id, semesterId: n.semester_id, subjectId: n.subject_id }); }}><Pencil /> Edit</Button>
                <Button variant="outline" size="sm" className="text-destructive" onClick={() => setDeleting(n)}><Trash2 /> Delete</Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>Edit note details</DialogTitle><DialogDescription>Branch and semester are fixed after upload.</DialogDescription></DialogHeader>
          {meta && <NoteMetaFields value={meta} onChange={setMeta} errors={errors} lockCourse />}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={() => save.mutate()} disabled={save.isPending}>{save.isPending && <Loader2 className="animate-spin" />} Save changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete this note?</AlertDialogTitle><AlertDialogDescription>"{deleting?.title}" and its PDF will be permanently removed.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); if (deleting) del.mutate(deleting); }} disabled={del.isPending}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
