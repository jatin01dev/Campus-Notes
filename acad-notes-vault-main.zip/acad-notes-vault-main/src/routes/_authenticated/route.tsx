import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { LoadingState } from "@/components/brand";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/login" });
  },
  component: Layout,
});

function Layout() {
  const { loading, profile } = useAuth();
  if (loading) return <LoadingState />;
  if (profile?.is_suspended) {
    return (
      <AppShell>
        <div className="surface p-8 text-center">
          <h1 className="text-xl font-bold">Your account is suspended</h1>
          <p className="mt-2 text-muted-foreground">Please contact an administrator if you think this is a mistake.</p>
        </div>
      </AppShell>
    );
  }
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
