import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Search, X } from "lucide-react";
import { useEffect, useState } from "react";
import { z } from "zod";
import { EmptyState, ErrorState, LoadingState, PageHeader } from "@/components/brand";
import { NoteCard } from "@/components/note-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useCatalog } from "@/lib/catalog";
import { APP_CONFIG } from "@/lib/config";
import { NOTE_SELECT, type NoteWithRefs } from "@/lib/notes";
import { sanitizeSearch } from "@/lib/validation";

const searchSchema = z.object({
  q: z.string().optional(),
  branch: z.string().optional(),
  semester: z.string().optional(),
  subject: z.string().optional(),
  sort: z.enum(["newest", "title"]).optional(),
  page: z.number().int().min(1).optional(),
});

export const Route = createFileRoute("/_authenticated/notes/")({
  validateSearch: searchSchema,
  head: () => ({ meta: [{ title: "Notes Library — CampusNotes" }, { name: "description", content: "Search and filter college notes by branch, semester and subject." }, { property: "og:title", content: "Notes Library — CampusNotes" }, { property: "og:description", content: "Browse every approved note on CampusNotes." }] }),
  component: Library,
});

const ALL = "all";

function Library() {
  const s = Route.useSearch();
  const navigate = useNavigate({ from: "/notes/" });
  const { data: catalog } = useCatalog();
  const [text, setText] = useState(s.q ?? "");
  const page = s.page ?? 1;
  const sort = s.sort ?? "newest";

  useEffect(() => setText(s.q ?? ""), [s.q]);
  useEffect(() => {
    const t = setTimeout(() => {
      if ((s.q ?? "") !== text.trim()) navigate({ search: (p) => ({ ...p, q: text.trim() || undefined, page: undefined }) });
    }, 350);
    return () => clearTimeout(t);
  }, [text]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (patch: Partial<z.infer<typeof searchSchema>>) => navigate({ search: (p) => ({ ...p, ...patch, page: patch.page }) });

  const query = useQuery({
    queryKey: ["notes", "library", s],
    placeholderData: keepPreviousData,
    queryFn: async () => {
      let req = supabase.from("notes").select(NOTE_SELECT, { count: "exact" }).eq("moderation_status", "approved");
      if (s.branch) req = req.eq("branch_id", s.branch);
      if (s.semester) req = req.eq("semester_id", s.semester);
      if (s.subject) req = req.eq("subject_id", s.subject);
      const term = sanitizeSearch(s.q ?? "");
      if (term) {
        const { data: subs } = await supabase.from("subjects").select("id").ilike("name", `%${term}%`).limit(50);
        const parts = [`title.ilike.%${term}%`, `description.ilike.%${term}%`];
        if (subs?.length) parts.push(`subject_id.in.(${subs.map((x) => x.id).join(",")})`);
        req = req.or(parts.join(","));
      }
      req = sort === "title" ? req.order("title") : req.order("created_at", { ascending: false });
      const from = (page - 1) * APP_CONFIG.pageSize;
      const { data, error, count } = await req.range(from, from + APP_CONFIG.pageSize - 1);
      if (error) throw error;
      return { notes: data as unknown as NoteWithRefs[], count: count ?? 0 };
    },
  });

  const subjects = (catalog?.subjects ?? []).filter((x) => (!s.branch || x.branch_id === s.branch) && (!s.semester || x.semester_id === s.semester));
  const totalPages = Math.max(1, Math.ceil((query.data?.count ?? 0) / APP_CONFIG.pageSize));
  const hasFilters = !!(s.q || s.branch || s.semester || s.subject || s.sort);

  return (
    <div>
      <PageHeader title="Notes Library" description="Find study material by branch, semester and subject." />
      <div className="surface mb-6 grid gap-3 p-4 md:grid-cols-[1fr_repeat(4,minmax(0,160px))_auto]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Search title, subject, description" aria-label="Search notes" className="h-10 pl-9" />
        </div>
        <Select value={s.branch ?? ALL} onValueChange={(v) => set({ branch: v === ALL ? undefined : v, subject: undefined })}>
          <SelectTrigger className="h-10" aria-label="Branch"><SelectValue placeholder="Branch" /></SelectTrigger>
          <SelectContent><SelectItem value={ALL}>All branches</SelectItem>{catalog?.branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.code} — {b.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={s.semester ?? ALL} onValueChange={(v) => set({ semester: v === ALL ? undefined : v, subject: undefined })}>
          <SelectTrigger className="h-10" aria-label="Semester"><SelectValue placeholder="Semester" /></SelectTrigger>
          <SelectContent><SelectItem value={ALL}>All semesters</SelectItem>{catalog?.semesters.map((x) => <SelectItem key={x.id} value={x.id}>{x.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={s.subject ?? ALL} onValueChange={(v) => set({ subject: v === ALL ? undefined : v })}>
          <SelectTrigger className="h-10" aria-label="Subject"><SelectValue placeholder="Subject" /></SelectTrigger>
          <SelectContent><SelectItem value={ALL}>All subjects</SelectItem>{subjects.map((x) => <SelectItem key={x.id} value={x.id}>{x.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={sort} onValueChange={(v) => set({ sort: v === "newest" ? undefined : (v as "title") })}>
          <SelectTrigger className="h-10" aria-label="Sort"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="newest">Newest first</SelectItem><SelectItem value="title">Title A–Z</SelectItem></SelectContent>
        </Select>
        <Button variant="ghost" className="h-10" disabled={!hasFilters} onClick={() => { setText(""); navigate({ search: {} }); }}><X /> Clear</Button>
      </div>

      {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : !query.data?.notes.length ? (
        <EmptyState title="No matching notes" description={hasFilters ? "Try a different search term or clear some filters." : "No notes have been published yet."} action={hasFilters ? <Button variant="outline" onClick={() => navigate({ search: {} })}>Clear filters</Button> : undefined} />
      ) : (
        <>
          <p className="mb-3 text-sm text-muted-foreground">{query.data.count} note{query.data.count === 1 ? "" : "s"} found</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{query.data.notes.map((n) => <NoteCard key={n.id} note={n} />)}</div>
          {totalPages > 1 && (
            <div className="mt-8 flex items-center justify-center gap-3">
              <Button variant="outline" disabled={page <= 1} onClick={() => set({ page: page - 1 })}><ChevronLeft /> Previous</Button>
              <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
              <Button variant="outline" disabled={page >= totalPages} onClick={() => set({ page: page + 1 })}>Next <ChevronRight /></Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
