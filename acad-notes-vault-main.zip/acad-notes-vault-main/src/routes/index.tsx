import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Bookmark, Filter, Search, ShieldCheck, Upload, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PublicLayout } from "@/components/site-chrome";
import { supabase } from "@/integrations/supabase/client";
import hero from "@/assets/hero-notes.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CampusNotes — Your College Notes. One Community." },
      { name: "description", content: "Discover, share, and access study materials from students across your college, organised by branch, semester and subject." },
      { property: "og:title", content: "CampusNotes — Your College Notes. One Community." },
      { property: "og:description", content: "Discover, share, and access study materials from students across your college." },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: Search, title: "Find notes fast", text: "Search by title, subject or description and get straight to what you need." },
  { icon: Filter, title: "Organised by course", text: "Filter by branch, semester and subject — no more digging through group chats." },
  { icon: Bookmark, title: "Save for later", text: "Bookmark useful notes and find them again on any device." },
  { icon: ShieldCheck, title: "Reviewed content", text: "Uploads are moderated so the library stays accurate and useful." },
];

const steps = [
  { n: "01", title: "Create your account", text: "Sign up with your college email, branch and semester." },
  { n: "02", title: "Explore the library", text: "Browse, preview and download notes shared by classmates." },
  { n: "03", title: "Share your own", text: "Apply to become a contributor and upload your best PDFs." },
];

function Landing() {
  const { data: stats } = useQuery({
    queryKey: ["public-stats"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_public_stats");
      if (error) throw error;
      return data as { notes: number; subjects: number; branches: number };
    },
  });

  return (
    <PublicLayout>
      <section className="dot-grid border-b">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs font-semibold text-primary">
              Built for college students
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.05] sm:text-5xl lg:text-6xl">
              Your College Notes. <span className="text-primary">One Community.</span>
            </h1>
            <p className="mt-5 max-w-lg text-lg text-muted-foreground">
              Discover, share, and access study materials from students across your college. Find the right notes for your branch, semester, and subjects.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" asChild><Link to="/notes">Explore Notes <ArrowRight /></Link></Button>
              <Button size="lg" variant="outline" asChild><Link to="/apply">Start Sharing</Link></Button>
            </div>
            {stats && (
              <dl className="mt-10 flex gap-8">
                <div><dt className="text-xs text-muted-foreground">Published notes</dt><dd className="font-display text-2xl font-bold">{stats.notes}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Subjects</dt><dd className="font-display text-2xl font-bold">{stats.subjects}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Branches</dt><dd className="font-display text-2xl font-bold">{stats.branches}</dd></div>
              </dl>
            )}
          </div>
          <div className="surface overflow-hidden p-2">
            <img src={hero} alt="Open notebook with study notes beside a stack of PDF documents" width={1280} height={960} className="h-full w-full rounded-lg object-cover" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="text-3xl font-bold">Everything you need to study smarter</h2>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="surface p-6">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary-soft text-primary"><f.icon className="h-5 w-5" /></div>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y bg-card">
        <div className="mx-auto max-w-6xl px-4 py-20">
          <h2 className="text-3xl font-bold">How it works</h2>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.n}>
                <span className="font-display text-sm font-bold text-primary">{s.n}</span>
                <h3 className="mt-2 text-lg font-semibold">{s.title}</h3>
                <p className="mt-1 text-muted-foreground">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-20 md:grid-cols-2">
        <div>
          <h2 className="text-3xl font-bold">Why sharing knowledge matters</h2>
          <p className="mt-4 text-muted-foreground">
            The best notes often sit in one student's notebook. When you share them, juniors get a head start, classmates fill gaps before exams, and you strengthen your own understanding by organising what you've learned.
          </p>
        </div>
        <div className="space-y-4">
          {[
            { icon: Users, t: "Help your peers", d: "Every upload saves someone hours of searching." },
            { icon: Upload, t: "Build your reputation", d: "See how many students download your notes." },
          ].map((x) => (
            <div key={x.t} className="surface flex gap-4 p-5">
              <x.icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <div><h3 className="font-semibold">{x.t}</h3><p className="text-sm text-muted-foreground">{x.d}</p></div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-20">
        <div className="flex flex-col items-start justify-between gap-6 rounded-2xl bg-ink p-8 text-ink-foreground sm:p-12 md:flex-row md:items-center">
          <div>
            <h2 className="text-2xl font-bold sm:text-3xl">Have great notes? Become a contributor.</h2>
            <p className="mt-2 opacity-80">Apply in under a minute. Once approved, you can upload PDFs for everyone.</p>
          </div>
          <Button size="lg" asChild><Link to="/register">Get Started <ArrowRight /></Link></Button>
        </div>
      </section>
    </PublicLayout>
  );
}
