import { createFileRoute } from "@tanstack/react-router";
import { ContentPage } from "@/components/site-chrome";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — CampusNotes" },
      { name: "description", content: "CampusNotes is a student-run notes-sharing platform for colleges." },
      { property: "og:title", content: "About — CampusNotes" },
      { property: "og:description", content: "Why we built a notes-sharing platform for college students." },
    ],
  }),
  component: () => (
    <ContentPage title="About CampusNotes">
      <p>CampusNotes helps college students upload, organise, discover and download study materials. Notes are organised by branch, semester and subject so you can find exactly what your course needs.</p>
      <p>Content is shared by approved student contributors and reviewed by administrators, keeping the library trustworthy and free of clutter.</p>
    </ContentPage>
  ),
});
