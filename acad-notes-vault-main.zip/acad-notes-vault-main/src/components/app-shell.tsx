import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Bookmark, FileUp, FolderOpen, LayoutDashboard, Library, LogOut, Menu, Shield, UserRound, Award } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import { roleLabel, useAuth } from "@/lib/auth";
import { Logo } from "./brand";

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  const { canUpload, isAdmin } = useAuth();
  const items = [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, show: true },
    { to: "/notes", label: "Notes Library", icon: Library, show: true },
    { to: "/bookmarks", label: "Bookmarks", icon: Bookmark, show: true },
    { to: "/upload", label: "Upload Notes", icon: FileUp, show: canUpload },
    { to: "/my-uploads", label: "My Uploads", icon: FolderOpen, show: canUpload },
    { to: "/apply", label: "Become a Contributor", icon: Award, show: !canUpload },
    { to: "/profile", label: "Profile", icon: UserRound, show: true },
    { to: "/admin", label: "Admin", icon: Shield, show: isAdmin },
  ] as const;
  return (
    <nav className="flex flex-col gap-1" aria-label="App">
      {items.filter((i) => i.show).map((i) => (
        <Link
          key={i.to}
          to={i.to}
          onClick={onNavigate}
          className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          activeProps={{ className: "bg-primary-soft text-primary hover:bg-primary-soft hover:text-primary" }}
          activeOptions={{ exact: i.to === "/notes" ? false : true }}
        >
          <i.icon className="h-4 w-4" /> {i.label}
        </Link>
      ))}
    </nav>
  );
}

function UserBox() {
  const { profile, roles, user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }
  return (
    <div className="border-t pt-4">
      <div className="mb-3 px-1">
        <p className="truncate text-sm font-semibold">{profile?.full_name ?? user?.email}</p>
        <p className="text-xs text-muted-foreground">{roleLabel(roles)}</p>
      </div>
      <Button variant="outline" className="w-full justify-start" onClick={signOut}>
        <LogOut /> Log out
      </Button>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[256px_1fr]">
      <aside className="sticky top-0 hidden h-screen flex-col justify-between border-r bg-sidebar p-4 lg:flex">
        <div>
          <Logo className="mb-8 px-1" />
          <NavItems />
        </div>
        <UserBox />
      </aside>
      <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b bg-card/90 px-4 backdrop-blur lg:hidden">
        <Logo />
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Open menu"><Menu /></Button>
          </SheetTrigger>
          <SheetContent side="left" className="flex w-72 flex-col justify-between p-4">
            <div>
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <Logo className="mb-8 px-1" />
              <NavItems onNavigate={() => setOpen(false)} />
            </div>
            <UserBox />
          </SheetContent>
        </Sheet>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:py-10">{children}</main>
    </div>
  );
}
