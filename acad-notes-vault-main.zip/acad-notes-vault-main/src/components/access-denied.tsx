import { Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "./brand";

export function AccessDenied({ message, showApply }: { message: string; showApply?: boolean }) {
  return (
    <EmptyState
      icon={<Lock className="h-5 w-5" />}
      title="You don't have access"
      description={message}
      action={showApply ? <Button asChild><Link to="/apply">Apply to contribute</Link></Button> : <Button variant="outline" asChild><Link to="/dashboard">Back to dashboard</Link></Button>}
    />
  );
}
