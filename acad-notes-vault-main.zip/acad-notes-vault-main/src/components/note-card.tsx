import { Link } from "@tanstack/react-router";
import { Bookmark, BookmarkCheck, Download, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBookmarkIds, useToggleBookmark } from "@/lib/bookmarks";
import { formatDate, type NoteWithRefs } from "@/lib/notes";
import { cn } from "@/lib/utils";

export function NoteCard({ note }: { note: NoteWithRefs }) {
  const { data: ids } = useBookmarkIds();
  const toggle = useToggleBookmark();
  const bookmarked = ids?.has(note.id) ?? false;
  return (
    <article className="surface surface-hover flex flex-col p-5">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-danger-soft text-destructive">
            <FileText className="h-4 w-4" />
          </span>
          <span className="text-xs font-semibold uppercase tracking-wide text-primary">{note.subjects?.name}</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          aria-label={bookmarked ? "Remove bookmark" : "Bookmark note"}
          aria-pressed={bookmarked}
          disabled={toggle.isPending}
          onClick={() => toggle.mutate({ noteId: note.id, bookmarked })}
          className={cn("-mr-2 -mt-1", bookmarked && "text-primary")}
        >
          {bookmarked ? <BookmarkCheck /> : <Bookmark />}
        </Button>
      </div>
      <h3 className="line-clamp-2 text-base font-semibold leading-snug">{note.title}</h3>
      {note.description && <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{note.description}</p>}
      <div className="mt-3 flex flex-wrap gap-1.5 text-xs">
        <span className="rounded-md bg-secondary px-2 py-0.5 font-medium">{note.branches?.code}</span>
        <span className="rounded-md bg-secondary px-2 py-0.5 font-medium">Sem {note.semesters?.number}</span>
        <span className="rounded-md bg-secondary px-2 py-0.5 font-medium">PDF</span>
        {note.is_demo && <span className="rounded-md bg-warning-soft px-2 py-0.5 font-medium text-warning">Demo</span>}
      </div>
      <div className="mt-auto flex items-center justify-between gap-2 pt-4 text-xs text-muted-foreground">
        <span className="truncate">{note.uploader_name ?? "Contributor"} · {formatDate(note.created_at)}</span>
        <span className="flex shrink-0 items-center gap-1"><Download className="h-3 w-3" />{note.download_count}</span>
      </div>
      <Button variant="soft" size="sm" className="mt-4" asChild>
        <Link to="/notes/$noteId" params={{ noteId: note.id }}>View details</Link>
      </Button>
    </article>
  );
}
