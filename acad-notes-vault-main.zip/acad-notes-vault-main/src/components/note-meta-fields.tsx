import { Field } from "@/components/auth-card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCatalog } from "@/lib/catalog";
import { z } from "zod";

export type NoteMeta = { title: string; description: string; branchId: string; semesterId: string; subjectId: string };
export const emptyMeta: NoteMeta = { title: "", description: "", branchId: "", semesterId: "", subjectId: "" };

export const metaSchema = z.object({
  title: z.string().trim().min(3, "Title must be at least 3 characters").max(150),
  description: z.string().trim().max(2000, "Keep the description under 2000 characters"),
  branchId: z.string().min(1, "Select a branch"),
  semesterId: z.string().min(1, "Select a semester"),
  subjectId: z.string().min(1, "Select a subject"),
});

export function NoteMetaFields({ value, onChange, errors, lockCourse }: { value: NoteMeta; onChange: (v: NoteMeta) => void; errors: Record<string, string>; lockCourse?: boolean | undefined }) {
  const { data: catalog } = useCatalog();
  const subjects = (catalog?.subjects ?? []).filter((s) => s.branch_id === value.branchId && s.semester_id === value.semesterId);
  return (
    <div className="space-y-4">
      <Field id="title" label="Notes title" error={errors["title"]}>
        <Input id="title" className="h-10" maxLength={150} value={value.title} onChange={(e) => onChange({ ...value, title: e.target.value })} />
      </Field>
      <Field id="description" label="Description" error={errors["description"]}>
        <Textarea id="description" rows={4} maxLength={2000} value={value.description} onChange={(e) => onChange({ ...value, description: e.target.value })} placeholder="What topics do these notes cover?" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field id="branch" label="Branch" error={errors["branchId"]}>
          <Select disabled={!!lockCourse} value={value.branchId} onValueChange={(v) => onChange({ ...value, branchId: v, subjectId: "" })}>
            <SelectTrigger id="branch" className="h-10"><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent>{catalog?.branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.code} — {b.name}</SelectItem>)}</SelectContent>
          </Select>
        </Field>
        <Field id="semester" label="Semester" error={errors["semesterId"]}>
          <Select disabled={!!lockCourse} value={value.semesterId} onValueChange={(v) => onChange({ ...value, semesterId: v, subjectId: "" })}>
            <SelectTrigger id="semester" className="h-10"><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent>{catalog?.semesters.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
          </Select>
        </Field>
        <Field id="subject" label="Subject" error={errors["subjectId"]}>
          <Select value={value.subjectId} onValueChange={(v) => onChange({ ...value, subjectId: v })} disabled={!value.branchId || !value.semesterId}>
            <SelectTrigger id="subject" className="h-10"><SelectValue placeholder={subjects.length || !value.branchId || !value.semesterId ? "Select" : "No subjects yet"} /></SelectTrigger>
            <SelectContent>{subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
          </Select>
        </Field>
      </div>
    </div>
  );
}
