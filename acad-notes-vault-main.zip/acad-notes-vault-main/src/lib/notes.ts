import { supabase } from "@/integrations/supabase/client";
import { APP_CONFIG } from "./config";

export const NOTE_SELECT =
  "*, subjects(name), branches(name, code), semesters(number, name)" as const;

export type NoteWithRefs = {
  id: string;
  title: string;
  description: string | null;
  branch_id: string;
  semester_id: string;
  subject_id: string;
  storage_path: string;
  file_size: number | null;
  uploaded_by: string;
  uploader_name: string | null;
  is_demo: boolean;
  moderation_status: "pending" | "approved" | "rejected";
  download_count: number;
  created_at: string;
  updated_at: string;
  subjects: { name: string } | null;
  branches: { name: string; code: string } | null;
  semesters: { number: number; name: string } | null;
};

function safeFileName(title: string) {
  return (title.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").slice(0, 60) || "notes") + ".pdf";
}

/** Creates a short-lived link (permission checked by storage policies), records the download, then starts it. */
export async function downloadNote(note: Pick<NoteWithRefs, "id" | "title" | "storage_path">) {
  const { data, error } = await supabase.storage
    .from("college-notes")
    .createSignedUrl(note.storage_path, APP_CONFIG.signedUrlSeconds, { download: safeFileName(note.title) });
  if (error || !data) throw error ?? new Error("Could not create download link");
  await supabase.rpc("record_download", { _note_id: note.id });
  const a = document.createElement("a");
  a.href = data.signedUrl;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

export async function getPreviewUrl(storagePath: string) {
  const { data, error } = await supabase.storage.from("college-notes").createSignedUrl(storagePath, 300);
  if (error || !data) throw error ?? new Error("Preview unavailable");
  return data.signedUrl;
}

export function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}
