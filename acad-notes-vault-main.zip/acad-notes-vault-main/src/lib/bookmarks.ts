import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { friendlyError, useAuth } from "./auth";

export function useBookmarkIds() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["bookmark-ids", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("bookmarks").select("note_id").eq("user_id", user!.id);
      if (error) throw error;
      return new Set(data.map((b) => b.note_id));
    },
  });
}

export function useToggleBookmark() {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ noteId, bookmarked }: { noteId: string; bookmarked: boolean }) => {
      if (!user) throw new Error("Not signed in");
      if (bookmarked) {
        const { error } = await supabase.from("bookmarks").delete().eq("user_id", user.id).eq("note_id", noteId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("bookmarks").insert({ user_id: user.id, note_id: noteId });
        if (error) throw error;
      }
      return !bookmarked;
    },
    onSuccess: (nowBookmarked) => {
      toast.success(nowBookmarked ? "Saved to bookmarks" : "Removed from bookmarks");
      qc.invalidateQueries({ queryKey: ["bookmark-ids"] });
      qc.invalidateQueries({ queryKey: ["bookmarks"] });
    },
    onError: (e) => toast.error(friendlyError(e)),
  });
}
