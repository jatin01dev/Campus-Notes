import { describe, expect, it } from "vitest";
import { buildStoragePath, checkPdfBasics, hasPdfSignature, isAllowedEmail, sanitizeSearch } from "./validation";

describe("upload rules", () => {
  it("rejects non-PDF files", () => {
    expect(checkPdfBasics({ name: "notes.docx", size: 100, type: "application/msword" }).ok).toBe(false);
  });
  it("rejects files over 10 MB", () => {
    expect(checkPdfBasics({ name: "a.pdf", size: 10 * 1024 * 1024 + 1, type: "application/pdf" }).ok).toBe(false);
  });
  it("accepts a 10 MB PDF", () => {
    expect(checkPdfBasics({ name: "a.pdf", size: 10 * 1024 * 1024, type: "application/pdf" }).ok).toBe(true);
  });
  it("requires the PDF signature, not just the extension", () => {
    expect(hasPdfSignature(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d]))).toBe(true);
    expect(hasPdfSignature(new Uint8Array([0x50, 0x4b, 0x03, 0x04, 0x00]))).toBe(false);
  });
  it("stores files under the uploader's own folder", () => {
    expect(buildStoragePath("u1", "f1")).toBe("notes/u1/f1.pdf");
  });
});

describe("registration and search", () => {
  it("allows any email when no domains are configured", () => {
    expect(isAllowedEmail("a@gmail.com", [])).toBe(true);
  });
  it("restricts to configured college domains", () => {
    expect(isAllowedEmail("a@gmail.com", ["college.edu"])).toBe(false);
    expect(isAllowedEmail("a@College.edu", ["college.edu"])).toBe(true);
  });
  it("removes filter-breaking characters from search", () => {
    expect(sanitizeSearch("dbms,(id.eq.1)")).toBe("dbms id.eq.1");
  });
});
