import { queryOptions, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const catalogQuery = queryOptions({
  queryKey: ["catalog"],
  queryFn: async () => {
    const [b, s, sub] = await Promise.all([
      supabase.from("branches").select("*").order("name"),
      supabase.from("semesters").select("*").order("number"),
      supabase.from("subjects").select("*").order("name"),
    ]);
    if (b.error) throw b.error;
    if (s.error) throw s.error;
    if (sub.error) throw sub.error;
    return { branches: b.data, semesters: s.data, subjects: sub.data };
  },
  staleTime: 5 * 60 * 1000,
});

export function useCatalog() {
  return useQuery(catalogQuery);
}
