/** App-wide settings. Change these values to configure CampusNotes. */
export const APP_CONFIG = {
  /** Largest PDF a contributor may upload, in megabytes. Keep in sync with the storage bucket limit. */
  maxUploadMb: 10,
  /**
   * Restrict registration to these email domains (e.g. ["mycollege.edu"]).
   * Leave empty to allow any email address.
   */
  allowedEmailDomains: [] as string[],
  /** Seconds a download / preview link stays valid. */
  signedUrlSeconds: 60,
  pageSize: 12,
};
