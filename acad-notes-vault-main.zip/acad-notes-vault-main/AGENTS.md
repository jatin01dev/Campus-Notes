<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## CampusNotes architecture
- Data access is browser-side via the generated client; all permissions are enforced by RLS, triggers and SECURITY DEFINER RPCs (review_application, record_download, etc.) — why: UI checks are cosmetic only.
- Roles live only in `user_roles`; changes go through admin RPCs, never direct writes — why: prevents privilege escalation.
- PDFs live in private bucket `college-notes` at `notes/{uid}/{uuid}.pdf`, served via short-lived signed URLs — why: no permanent public links.
- Signed-in pages live under `src/routes/_authenticated/` (ssr:false); auth/role state comes from `useAuth` in `src/lib/auth.tsx`.
- Tunable limits (upload size, allowed email domains, page size) live in `src/lib/config.ts`.
