
CREATE POLICY "notes upload own folder" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'college-notes'
  AND (storage.foldername(name))[1] = 'notes'
  AND (storage.foldername(name))[2] = auth.uid()::text
  AND name ~ '^notes/[0-9a-f-]{36}/[0-9a-f-]{36}\.pdf$'
  AND public.can_upload(auth.uid())
);

CREATE POLICY "notes read authorized" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'college-notes' AND public.is_active_user(auth.uid()) AND (
    (storage.foldername(name))[2] = auth.uid()::text
    OR public.has_role(auth.uid(),'admin')
    OR EXISTS (SELECT 1 FROM public.notes n WHERE n.storage_path = storage.objects.name AND n.moderation_status = 'approved')
  )
);

CREATE POLICY "notes delete own or admin" ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'college-notes' AND (
    (storage.foldername(name))[2] = auth.uid()::text
    OR public.has_role(auth.uid(),'admin')
  )
);
