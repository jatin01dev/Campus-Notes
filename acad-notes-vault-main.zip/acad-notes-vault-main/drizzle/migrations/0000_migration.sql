
-- Enums
CREATE TYPE public.app_role AS ENUM ('student','contributor','admin');
CREATE TYPE public.moderation_status AS ENUM ('pending','approved','rejected');
CREATE TYPE public.application_status AS ENUM ('pending','approved','rejected');
CREATE TYPE public.report_status AS ENUM ('open','reviewing','resolved');

-- Catalog
CREATE TABLE public.branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  code text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.semesters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number int NOT NULL UNIQUE CHECK (number BETWEEN 1 AND 12),
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  semester_id uuid NOT NULL REFERENCES public.semesters(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (name, branch_id, semester_id)
);
CREATE INDEX ON public.subjects(branch_id, semester_id);

-- Profiles & roles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL CHECK (char_length(full_name) BETWEEN 1 AND 120),
  email text,
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  semester_id uuid REFERENCES public.semesters(id) ON DELETE SET NULL,
  is_suspended boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_active_user(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND NOT is_suspended)
$$;

CREATE OR REPLACE FUNCTION public.can_upload(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_active_user(_user_id)
     AND (public.has_role(_user_id,'contributor') OR public.has_role(_user_id,'admin'))
$$;

-- Notes
CREATE TABLE public.notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 150),
  description text CHECK (description IS NULL OR char_length(description) <= 2000),
  branch_id uuid NOT NULL REFERENCES public.branches(id),
  semester_id uuid NOT NULL REFERENCES public.semesters(id),
  subject_id uuid NOT NULL REFERENCES public.subjects(id),
  storage_path text NOT NULL UNIQUE,
  file_size bigint,
  uploaded_by uuid NOT NULL,
  uploader_name text,
  is_demo boolean NOT NULL DEFAULT false,
  moderation_status public.moderation_status NOT NULL DEFAULT 'pending',
  download_count int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON public.notes(moderation_status, created_at DESC);
CREATE INDEX ON public.notes(branch_id);
CREATE INDEX ON public.notes(semester_id);
CREATE INDEX ON public.notes(subject_id);
CREATE INDEX ON public.notes(uploaded_by);

CREATE TABLE public.bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  note_id uuid NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, note_id)
);
CREATE TABLE public.contributor_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  reason text CHECK (reason IS NULL OR char_length(reason) <= 1000),
  status public.application_status NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX one_pending_application ON public.contributor_applications(user_id) WHERE status = 'pending';
CREATE TABLE public.note_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_id uuid NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  reported_by uuid NOT NULL,
  reason text NOT NULL CHECK (char_length(reason) BETWEEN 2 AND 100),
  description text CHECK (description IS NULL OR char_length(description) <= 1000),
  status public.report_status NOT NULL DEFAULT 'open',
  reviewed_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX ON public.note_reports(status);
CREATE TABLE public.note_downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_id uuid NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  user_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON public.note_downloads(note_id);

-- Grants
GRANT SELECT ON public.branches, public.semesters, public.subjects TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.branches, public.semesters, public.subjects TO authenticated;
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.user_roles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notes TO authenticated;
GRANT SELECT, INSERT, DELETE ON public.bookmarks TO authenticated;
GRANT SELECT, INSERT ON public.contributor_applications TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.note_reports TO authenticated;
GRANT SELECT ON public.note_downloads TO authenticated;
GRANT ALL ON public.branches, public.semesters, public.subjects, public.profiles, public.user_roles, public.notes, public.bookmarks, public.contributor_applications, public.note_reports, public.note_downloads TO service_role;

ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.semesters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contributor_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.note_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.note_downloads ENABLE ROW LEVEL SECURITY;

-- Catalog policies
CREATE POLICY "catalog read" ON public.branches FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "catalog read" ON public.semesters FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "catalog read" ON public.subjects FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin write" ON public.branches FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin write" ON public.semesters FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin write" ON public.subjects FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Profiles
CREATE POLICY "own or admin read" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "own or admin update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(),'admin')) WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- Protected profile fields
CREATE OR REPLACE FUNCTION public.protect_profile_fields()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.id <> OLD.id OR NEW.email IS DISTINCT FROM OLD.email OR NEW.created_at <> OLD.created_at THEN
    RAISE EXCEPTION 'Protected fields cannot be changed';
  END IF;
  IF NEW.is_suspended <> OLD.is_suspended AND NOT public.has_role(auth.uid(),'admin') THEN
    RAISE EXCEPTION 'Only administrators can change account status';
  END IF;
  IF NEW.is_suspended AND NEW.id = auth.uid() THEN
    RAISE EXCEPTION 'You cannot suspend your own account';
  END IF;
  NEW.updated_at = now();
  RETURN NEW;
END $$;
CREATE TRIGGER profiles_protect BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.protect_profile_fields();

-- Roles: read own; admin read all. No write policies (changes via security definer functions only).
CREATE POLICY "own or admin read" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- Signup trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _branch uuid; _sem uuid;
BEGIN
  BEGIN _branch := NULLIF(NEW.raw_user_meta_data->>'branch_id','')::uuid; EXCEPTION WHEN others THEN _branch := NULL; END;
  BEGIN _sem := NULLIF(NEW.raw_user_meta_data->>'semester_id','')::uuid; EXCEPTION WHEN others THEN _sem := NULL; END;
  IF _branch IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.branches WHERE id = _branch) THEN _branch := NULL; END IF;
  IF _sem IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.semesters WHERE id = _sem) THEN _sem := NULL; END IF;
  INSERT INTO public.profiles (id, full_name, email, branch_id, semester_id)
  VALUES (NEW.id,
    left(COALESCE(NULLIF(trim(NEW.raw_user_meta_data->>'full_name'),''), NULLIF(trim(NEW.raw_user_meta_data->>'name'),''), split_part(NEW.email,'@',1)), 120),
    NEW.email, _branch, _sem);
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'student');
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Notes policies
CREATE POLICY "read approved, own, or admin" ON public.notes FOR SELECT TO authenticated
  USING (moderation_status = 'approved' OR uploaded_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "contributors insert own" ON public.notes FOR INSERT TO authenticated
  WITH CHECK (uploaded_by = auth.uid() AND public.can_upload(auth.uid()));
CREATE POLICY "owner or admin update" ON public.notes FOR UPDATE TO authenticated
  USING (uploaded_by = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (uploaded_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "owner or admin delete" ON public.notes FOR DELETE TO authenticated
  USING (uploaded_by = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.notes_guard()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _is_admin boolean := public.has_role(auth.uid(),'admin');
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.subjects s WHERE s.id = NEW.subject_id AND s.branch_id = NEW.branch_id AND s.semester_id = NEW.semester_id) THEN
    RAISE EXCEPTION 'Subject does not belong to the selected branch and semester';
  END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.storage_path !~ ('^notes/' || NEW.uploaded_by::text || '/[0-9a-f-]{36}\.pdf$') THEN
      RAISE EXCEPTION 'Invalid storage path';
    END IF;
    NEW.download_count := 0;
    NEW.is_demo := false;
    NEW.uploader_name := (SELECT full_name FROM public.profiles WHERE id = NEW.uploaded_by);
    IF NOT _is_admin THEN NEW.moderation_status := 'pending'; END IF;
  ELSE
    IF NEW.storage_path <> OLD.storage_path OR NEW.uploaded_by <> OLD.uploaded_by OR NEW.is_demo <> OLD.is_demo THEN
      RAISE EXCEPTION 'Protected fields cannot be changed';
    END IF;
    IF NEW.download_count <> OLD.download_count AND current_setting('app.counting', true) IS DISTINCT FROM 'on' THEN
      NEW.download_count := OLD.download_count;
    END IF;
    IF NOT _is_admin THEN
      IF NEW.moderation_status <> OLD.moderation_status THEN
        RAISE EXCEPTION 'Only administrators can change moderation status';
      END IF;
      -- Edited metadata goes back to review
      IF (NEW.title, NEW.description, NEW.subject_id) IS DISTINCT FROM (OLD.title, OLD.description, OLD.subject_id)
         AND current_setting('app.counting', true) IS DISTINCT FROM 'on' THEN
        NEW.moderation_status := 'pending';
      END IF;
    END IF;
    NEW.updated_at := now();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER notes_guard BEFORE INSERT OR UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.notes_guard();

-- Bookmarks
CREATE POLICY "own bookmarks read" ON public.bookmarks FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "own bookmarks insert" ON public.bookmarks FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "own bookmarks delete" ON public.bookmarks FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Applications
CREATE POLICY "own or admin read" ON public.contributor_applications FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "own insert pending" ON public.contributor_applications FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND status = 'pending' AND reviewed_by IS NULL AND reviewed_at IS NULL
              AND public.is_active_user(auth.uid()) AND NOT public.has_role(auth.uid(),'contributor'));

-- Reports
CREATE POLICY "own or admin read" ON public.note_reports FOR SELECT TO authenticated USING (reported_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "users report" ON public.note_reports FOR INSERT TO authenticated
  WITH CHECK (reported_by = auth.uid() AND status = 'open' AND reviewed_by IS NULL AND resolved_at IS NULL);
CREATE POLICY "admin update" ON public.note_reports FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Downloads
CREATE POLICY "own or admin read" ON public.note_downloads FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- RPCs
CREATE OR REPLACE FUNCTION public.record_download(_note_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_active_user(auth.uid()) THEN RAISE EXCEPTION 'Not allowed'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.notes WHERE id = _note_id AND (moderation_status='approved' OR uploaded_by = auth.uid() OR public.has_role(auth.uid(),'admin'))) THEN
    RAISE EXCEPTION 'Note not found';
  END IF;
  INSERT INTO public.note_downloads (note_id, user_id) VALUES (_note_id, auth.uid());
  PERFORM set_config('app.counting','on', true);
  UPDATE public.notes SET download_count = download_count + 1 WHERE id = _note_id;
  PERFORM set_config('app.counting','off', true);
END $$;

CREATE OR REPLACE FUNCTION public.review_application(_application_id uuid, _approve boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Forbidden'; END IF;
  UPDATE public.contributor_applications
     SET status = CASE WHEN _approve THEN 'approved'::application_status ELSE 'rejected'::application_status END,
         reviewed_by = auth.uid(), reviewed_at = now()
   WHERE id = _application_id AND status = 'pending'
   RETURNING user_id INTO _uid;
  IF _uid IS NULL THEN RAISE EXCEPTION 'Application not found or already reviewed'; END IF;
  IF _approve THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (_uid, 'contributor') ON CONFLICT DO NOTHING;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.revoke_contributor(_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Forbidden'; END IF;
  DELETE FROM public.user_roles WHERE user_id = _user_id AND role = 'contributor';
END $$;

CREATE OR REPLACE FUNCTION public.get_public_stats()
RETURNS json LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT json_build_object(
    'notes', (SELECT count(*) FROM public.notes WHERE moderation_status='approved' AND NOT is_demo),
    'subjects', (SELECT count(*) FROM public.subjects),
    'branches', (SELECT count(*) FROM public.branches)
  )
$$;

CREATE OR REPLACE FUNCTION public.get_admin_stats()
RETURNS json LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Forbidden'; END IF;
  RETURN json_build_object(
    'users', (SELECT count(*) FROM public.profiles),
    'contributors', (SELECT count(DISTINCT user_id) FROM public.user_roles WHERE role='contributor'),
    'notes', (SELECT count(*) FROM public.notes),
    'pending_notes', (SELECT count(*) FROM public.notes WHERE moderation_status='pending'),
    'pending_applications', (SELECT count(*) FROM public.contributor_applications WHERE status='pending'),
    'open_reports', (SELECT count(*) FROM public.note_reports WHERE status <> 'resolved'),
    'downloads', (SELECT count(*) FROM public.note_downloads)
  );
END $$;

REVOKE EXECUTE ON FUNCTION public.record_download(uuid), public.review_application(uuid, boolean), public.revoke_contributor(uuid), public.get_admin_stats() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.record_download(uuid), public.review_application(uuid, boolean), public.revoke_contributor(uuid), public.get_admin_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_public_stats() TO anon, authenticated;

-- Seed catalog
INSERT INTO public.branches (name, code) VALUES
 ('Computer Science and Engineering','CSE'),
 ('Electronics and Communication Engineering','ECE'),
 ('Mechanical Engineering','ME'),
 ('Civil Engineering','CE');
INSERT INTO public.semesters (number, name) SELECT n, 'Semester ' || n FROM generate_series(1,8) n;
INSERT INTO public.subjects (name, branch_id, semester_id)
SELECT s.name, b.id, sem.id FROM (VALUES
  ('Mathematics','CSE',1),('Mathematics','ECE',1),('Mathematics','ME',1),('Mathematics','CE',1),
  ('Java Programming','CSE',3),('Data Structures','CSE',3),('Digital Electronics','CSE',3),
  ('Database Management Systems','CSE',4),('Operating Systems','CSE',4),('Computer Networks','CSE',5),
  ('Digital Electronics','ECE',3),('Computer Networks','ECE',5),
  ('Engineering Mechanics','ME',2),('Thermodynamics','ME',3),
  ('Surveying','CE',3),('Structural Analysis','CE',4)
) AS s(name, code, sem)
JOIN public.branches b ON b.code = s.code
JOIN public.semesters sem ON sem.number = s.sem;
